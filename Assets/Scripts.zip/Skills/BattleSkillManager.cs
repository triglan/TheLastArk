using UnityEngine;
using System.Collections.Generic;

public class BattleSkillManager : MonoBehaviour
{
    public List<BattleCharacter> playerParty;
    public List<SkillGroupUI> skillGroups;

    public void LinkSkillsToUI()
    {
        for (int i = 0; i < skillGroups.Count; i++)
        {
            if (i < playerParty.Count && playerParty[i] != null)
            {
                skillGroups[i].gameObject.SetActive(true);
                // ����(activeSkills)�� �ƴ� ��Ÿ�� ������(dynamicActiveSkill) ����
                skillGroups[i].SetupGroup(playerParty[i].status.dynamicActiveSkill, playerParty[i]);
            }
            else { skillGroups[i].gameObject.SetActive(false); }
        }
    }
}
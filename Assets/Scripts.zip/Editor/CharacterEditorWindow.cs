using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

public class CharacterEditorWindow : EditorWindow
{
    private Vector2 scrollPos;
    private CharacterData selectedData;
    private int selectedSkillIndex = 0;

    [MenuItem("Window/Battle/Character Editor")]
    public static void ShowWindow()
    {
        GetWindow<CharacterEditorWindow>("ĳ���� ������");
    }

    private void OnGUI()
    {
        EditorGUILayout.BeginHorizontal();

        // --- ����: ĳ���� ����Ʈ ---
        DrawLeftPanel();

        // --- ������: ���� ����â ---
        DrawRightPanel();

        EditorGUILayout.EndHorizontal();
    }

    private void DrawLeftPanel()
    {
        EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.Width(200), GUILayout.ExpandHeight(true));
        EditorGUILayout.LabelField("ĳ���� ���", EditorStyles.boldLabel);

        if (GUILayout.Button("�� ĳ���� ����", GUILayout.Height(30)))
        {
            CreateNewCharacter();
        }

        EditorGUILayout.Space(10);

        string[] guids = AssetDatabase.FindAssets("t:CharacterData");
        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            CharacterData data = AssetDatabase.LoadAssetAtPath<CharacterData>(path);

            if (GUILayout.Toggle(selectedData == data, data.characterName, "Button", GUILayout.Height(25)))
            {
                selectedData = data;
                GUI.FocusControl(null); // ��Ŀ�� �����Ͽ� ��� �ݿ�
            }
        }
        EditorGUILayout.EndVertical();
    }

    private void DrawRightPanel()
    {
        if (selectedData == null)
        {
            EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));
            EditorGUILayout.LabelField("������ ĳ���͸� �����ϼ���.");
            EditorGUILayout.EndVertical();
            return;
        }

        scrollPos = EditorGUILayout.BeginScrollView(scrollPos);
        EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.ExpandWidth(true));

        // �⺻ ���� ����
        EditorGUILayout.LabelField($"�� {selectedData.characterName} ����", EditorStyles.whiteLargeLabel);
        EditorGUILayout.Space(10);

        selectedData.characterName = EditorGUILayout.TextField("ĳ���� �̸�", selectedData.characterName);
        selectedData.portraitSprite = (Sprite)EditorGUILayout.ObjectField("�ʻ�ȭ", selectedData.portraitSprite, typeof(Sprite), false);

        EditorGUILayout.Space(5);
        EditorGUILayout.LabelField("�⺻ ���� (0�� ����)", EditorStyles.boldLabel);
        selectedData.maxHp = EditorGUILayout.FloatField("�ִ� ü��", selectedData.maxHp);
        selectedData.maxMental = EditorGUILayout.FloatField("�ִ� ���ŷ�", selectedData.maxMental);
        selectedData.baseAttack = EditorGUILayout.FloatField("�⺻ ���ݷ�", selectedData.baseAttack);

        EditorGUILayout.Space(15);

        // ��ų ���� ���� (�� ���)
        EditorGUILayout.LabelField("��Ƽ�� ��ų ����", EditorStyles.boldLabel);
        string[] skillNames = new string[4];
        for (int i = 0; i < 4; i++)
            skillNames[i] = string.IsNullOrEmpty(selectedData.activeSkills[i]?.skillName) ? $"��ų {i + 1}" : selectedData.activeSkills[i].skillName;

        selectedSkillIndex = GUILayout.Toolbar(selectedSkillIndex, skillNames);

        DrawSkillEditor(selectedData.activeSkills[selectedSkillIndex]);

        EditorGUILayout.Space(20);
        if (GUI.changed)
        {
            EditorUtility.SetDirty(selectedData);
            AssetDatabase.SaveAssets();
        }

        EditorGUILayout.EndVertical();
        EditorGUILayout.EndScrollView();
    }

    private void DrawSkillEditor(SkillInfo skill)
    {
        if (skill == null) return;

        EditorGUILayout.BeginVertical(GUI.skin.textArea);
        skill.skillName = EditorGUILayout.TextField("��ų��", skill.skillName);
        skill.skillIcon = (Sprite)EditorGUILayout.ObjectField("������", skill.skillIcon, typeof(Sprite), false);
        skill.baseCost = EditorGUILayout.IntField("�⺻ �ڽ�Ʈ", skill.baseCost);

        EditorGUILayout.Space(10);

        // ������ ������ 3�ܰ踦 ���η� �����ϰų� ���η� ��Ȯ�� ǥ��
        for (int i = 0; i < 3; i++)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUILayout.LabelField($"{i + 1}�ܰ� ��ȭ ������", EditorStyles.miniBoldLabel);

            var levelData = skill.levels[i];
            levelData.overrideCost = EditorGUILayout.IntField("�ڽ�Ʈ (-1�� �⺻��)", levelData.overrideCost);
            levelData.targetType = (TargetType)EditorGUILayout.EnumPopup("Ÿ�� ����", levelData.targetType);

            // ����Ʈ ����Ʈ
            if (GUILayout.Button("+ ȿ�� �߰�", GUILayout.Width(100)))
                levelData.effects.Add(new EffectEntry());

            for (int e = 0; e < levelData.effects.Count; e++)
            {
                EditorGUILayout.BeginHorizontal();
                var effect = levelData.effects[e];
                effect.type = (EffectType)EditorGUILayout.EnumPopup(effect.type, GUILayout.Width(100));
                effect.multiplier = EditorGUILayout.FloatField("����", effect.multiplier, GUILayout.Width(80));
                effect.fixedValue = EditorGUILayout.FloatField("����ġ", effect.fixedValue, GUILayout.Width(80));
                if (GUILayout.Button("X", GUILayout.Width(20)))
                {
                    levelData.effects.RemoveAt(e);
                    break;
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndVertical();
    }

    private void CreateNewCharacter()
    {
        string path = EditorUtility.SaveFilePanelInProject("�� ĳ���� ����", "NewCharacter", "asset", "������ �̸��� �Է��ϼ���.");
        if (string.IsNullOrEmpty(path)) return;

        CharacterData newData = CreateInstance<CharacterData>();
        // �⺻ ���� �ʱ�ȭ ����
        newData.activeSkills = new SkillInfo[4];
        for (int i = 0; i < 4; i++)
        {
            newData.activeSkills[i] = new SkillInfo { levels = new SkillLevelData[3] };
            for (int j = 0; j < 3; j++) newData.activeSkills[i].levels[j] = new SkillLevelData();
        }

        AssetDatabase.CreateAsset(newData, path);
        AssetDatabase.SaveAssets();
        selectedData = newData;
    }
}